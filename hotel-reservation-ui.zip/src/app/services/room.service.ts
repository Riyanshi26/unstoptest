import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
@Injectable({
  providedIn: 'root'
})
export class RoomService {
  apiUrl = 'http://localhost:5000/api';
 
  constructor(private http: HttpClient) {}
 
  getRooms() {
    return this.http.get(`${this.apiUrl}/rooms`);
  }
 
  bookRooms(numRooms: number) {
    return this.http.post(`${this.apiUrl}/book`, { numRooms });
  }
 
  resetRooms() {
    return this.http.post(`${this.apiUrl}/reset`, {});
  }
 
  randomizeRooms() {
    return this.http.post(`${this.apiUrl}/randomize`, {}); // API call for random occupancy
  }
}
 