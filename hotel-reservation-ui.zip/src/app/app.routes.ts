import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
 
export const appRoutes: Routes = [
  { path: '', component: HomeComponent },  // Default route
  { path: '**', redirectTo: '' }             // Wildcard: redirect unknown routes to HomeComponent
];