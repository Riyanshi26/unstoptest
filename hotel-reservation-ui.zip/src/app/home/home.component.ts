import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RoomService } from '../services/room.service';
 
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  rooms: any[] = [];
  numRooms = 1;
 
  constructor(private roomService: RoomService) {}
 
  ngOnInit(): void {
    this.getRooms();
  }
 
  getRooms(): void {
    this.roomService.getRooms().subscribe((data: any) => {
      this.rooms = data;
    });
  }
 
  bookRooms(): void {
    this.roomService.bookRooms(this.numRooms).subscribe(() => {
      this.getRooms();
    });
  }
 
  resetRooms(): void {
    this.roomService.resetRooms().subscribe(() => {
      this.getRooms();
    });
  }
 
  randomizeRooms(): void {
    this.roomService.randomizeRooms().subscribe(() => {
      this.getRooms();
    });
  }
}